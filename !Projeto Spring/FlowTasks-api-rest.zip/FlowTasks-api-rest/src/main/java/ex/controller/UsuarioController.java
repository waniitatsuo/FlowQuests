package ex.controller;

import ex.model.Usuario;
import ex.model.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

//Importa a classe para criptografar senhas
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin("*")
public class UsuarioController {
	
	// Cria um objeto para criptografar e verificar senhas.
    @Autowired
    private UsuarioRepository repository;

    // Objeto para encriptar e verificar senhas.
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Endpoint para criar um novo usuário (Registrar)
    @PostMapping
    public ResponseEntity<Usuario> criar(@RequestBody Usuario novoUsuario) {
        novoUsuario.setId(null);
        
        // Encripta a senha antes de salvar no banco de dados
        String senhaEncriptada = passwordEncoder.encode(novoUsuario.getSenha());
        novoUsuario.setSenha(senhaEncriptada);
        
        // Salva o novo usuário no banco de dados
        Usuario usuarioSalvo = repository.save(novoUsuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioSalvo);
    }

    // Endpoint para processar o login
    @PostMapping("/login")
    public ResponseEntity<Usuario> login(@RequestBody Usuario dadosLogin) {
    	// Busca um usuário no banco pelo email fornecido
        Optional<Usuario> usuarioOptional = repository.findByEmail(dadosLogin.getEmail());

        // Verifica se o usuário existe
        if (usuarioOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 401 - Não autorizado (email não encontrado)
        }

        Usuario usuario = usuarioOptional.get();

        // Verifica se a senha enviada corresponde à senha encriptada no banco
        if (passwordEncoder.matches(dadosLogin.getSenha(), usuario.getSenha())) {
            return ResponseEntity.ok(usuario); // 200 - OK, login bem-sucedido
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 401 - Senha incorreta
        }
    }

    // Endpoint para listar todos os usuários
    @GetMapping
    public List<Usuario> listar() {
        return repository.findAll();
    }

    // Endpoint para buscar um usuário por ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Endpoint para atualizar um usuário existente
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> atualizar(@PathVariable Long id, @RequestBody Usuario usuarioAtualizado) {
        return repository.findById(id)
                .map(usuarioExistente -> {
                    usuarioExistente.setNome(usuarioAtualizado.getNome());
                    usuarioExistente.setEmail(usuarioAtualizado.getEmail());
                    // Adicione outros campos que possam ser atualizados
                    repository.save(usuarioExistente);
                    return ResponseEntity.ok(usuarioExistente);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Endpoint para deletar um usuário
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}